<p align="center">
  <img src="assets/logo.png" alt="CourseConnect" width="280">
</p>

<p align="center">
  <b>Find someone to learn from nearby.</b><br>
  A location-aware learning network prototype — browse mentors by skill, message them, and book sessions.
</p>

<p align="center">
  <a href="https://gloriackusuma.github.io/courseconnect/"><b>▶ Open the live demo</b></a>
</p>

---

## What it is

CourseConnect is a single-page, mobile-style web app prototype. It runs entirely in the browser — no backend, no build step, no dependencies. On a desktop it appears inside a phone frame; on a phone it fills the screen.

> **Note:** all mentors, chats and replies are sample data, and mentor replies are simulated. Nothing is sent anywhere.

## Features

**Discover**
- Search by skill or mentor name (with a clear button), filter by category, and sort by best match, top rated, lowest price or nearest
- Save mentors with the heart; open a full mentor profile
- Notification bell with a "Clear all" action

**Chats**
- A separate conversation thread per mentor
- Typing indicator and simulated replies; live relative timestamps ("2m", "Yesterday")
- Unread badge on the Chats tab

**Bookings**
- Month calendar with session dots and a "Today" shortcut
- Book a session: pick date, duration, format (online / in person) and time
- Past days are disabled, and time slots that have passed or clash with another session are greyed out
- Reschedule moves the existing booking; cancel with a confirmation

**Profile & settings**
- Learning / Teaching modes with editable skill tags, hourly rate and bio
- Editable display name and school, light / dark / auto theme
- Session reminders (today / tomorrow) and new-message notifications
- Everything is saved in your browser's `localStorage`; **Reset demo data** restores the samples

**Quality of life**
- Works on mobile and desktop, supports dark mode, keyboard navigation and reduced-motion
- `Esc` closes the topmost panel
- Installable to a phone home screen (web app manifest)

## Run it locally

No install needed — just open `index.html` in a browser.

Or serve the folder (optional):

```bash
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Publish with GitHub Pages

1. Push these files to the `main` branch of this repository.
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, set **Source** to **Deploy from a branch**, choose **main** and **/ (root)**, then **Save**.
4. After a minute the site is live at `https://<your-username>.github.io/courseconnect/`.

All file paths in the project are relative, so it works from that sub-path.

## Project structure

```
courseconnect/
├── index.html              # the whole app (HTML + CSS + JS)
├── manifest.webmanifest    # lets phones "install" the app
├── assets/
│   ├── logo.png            # full logo (used in this README)
│   ├── icon-192.png        # app icons
│   ├── icon-512.png
│   ├── apple-touch-icon.png
│   └── favicon.png
├── README.md
├── LICENSE
└── .gitignore
```

The header logo in `index.html` is embedded directly in the file, so it still shows even if the `assets/` folder is missing.

## Roadmap ideas

- Real accounts and a backend for mentors, messages and bookings
- Real location (replace the fixed "Kemanggisan, Jakarta Barat" label) and distance
- Mentor availability that feeds the time slots
- Ratings and reviews after a completed session

## License

Released under the [MIT License](LICENSE).
